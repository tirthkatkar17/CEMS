package com.eventmanagement.controller;

import com.eventmanagement.entity.Event;
import com.eventmanagement.repository.EventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/events")
@CrossOrigin(origins = "*")  // Allows connection from your frontend
public class EventController {

    @Autowired
    private EventRepository repository;

    // This method will fetch all events
    @GetMapping("/getAll")
    public List<Event> getAllEvents() {
        return repository.findAll();
    }

    // This method will create a new event
    @PostMapping("/create")
    public Event createEvent(@RequestBody Event event) {
        return repository.save(event);
    }

    // This method will get an event by its ID
    @GetMapping("/get/{id}")
    public Event getEventById(@PathVariable Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Event not found"));
    }
}
