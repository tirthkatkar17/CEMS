package com.eventmanagement.controller;

import com.eventmanagement.entity.Participant;
import com.eventmanagement.repository.ParticipantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/participants")
@CrossOrigin(origins = "*") // Allows connection from your frontend
public class ParticipantController {

    @Autowired
    private ParticipantRepository repository;

    // This method will handle registration
    @PostMapping("/register")
    public Participant registerParticipant(@RequestBody Participant participant) {
        participant.setPaymentStatus("Unpaid"); // Set default payment status
        return repository.save(participant);
    }


    // This method will fetch all registered participants for faculty dashboard
    @GetMapping("/getAll")
    public List<Participant> getAllParticipants() {
        return repository.findAll();
    }
}

