document.addEventListener('DOMContentLoaded', function() {
    const teamForm = document.getElementById("team-form");
    const nameInput = document.getElementById("name");
    const branchInput = document.getElementById("branch");
    const yearInput = document.getElementById("year");
    const scheduleInput = document.getElementById("campaigning-schedule");
    const timeInput = document.getElementById("time");
    const facultyInput = document.getElementById("faculty");
    const successMessage = document.getElementById("success-message");

    teamForm.addEventListener("submit", function(event) {
        event.preventDefault();

        // Prepare data - now reflects individual registration
        const formData = {
            name: nameInput.value.trim(),       // Your name
            branch: branchInput.value.trim(),  // Your branch
            year: yearInput.value.trim(),      // Your year
            campaigningSchedule: scheduleInput.value.trim(), // Your schedule
            time: timeInput.value.trim(),      // Time
            faculty: facultyInput.value.trim() // Faculty you're reporting to
        };

        fetch("http://localhost:8080/team/add", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(formData)
        })
        .then(response => {
            if (!response.ok) throw new Error('Registration failed');
            return response.text();
        })
        .then(message => {
            successMessage.textContent = message || "Team Member added successfully!";
            successMessage.style.display = "block";
            teamForm.reset();
            
            setTimeout(() => {
                successMessage.style.display = "none";
            }, 5000);
        })
        .catch(error => {
            console.error("Error:", error);
            successMessage.textContent = "Error: " + error.message;
            successMessage.style.color = "red";
            successMessage.style.display = "block";
        });
    });
});