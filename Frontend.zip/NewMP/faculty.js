function facultyLogin() {
    var username = document.getElementById("faculty-username").value;
    var password = document.getElementById("faculty-password").value;

    if (username === "faculty" && password === "kit123") {
        window.location.href = "faculty-dashboard.html"; // 🔁 Redirect to dashboard
    } else {
        document.getElementById("login-error").style.display = "block";
    }
}
