

const eventsData = {
    1: {
        title: "Code Wizard",
        department: "Computer Science",
        date: "April 22, 2025",
        venue: "Hall 101",
        description: "A coding competition where students solve programming challenges.",
        image: "cseimg.jpg",
        registerLink: "https://register.codewizard.com"
    },
    2: {
        title: "Beyond Resume",
        department: "AIML_DS",
        date: "April 20, 2025",
        venue: "Seminar Hall",
        description:
            "⿡ Aptitude Test 🖥 – Sharpen your problem-solving skills with a structured test.\n" +
            "⿢ Group Discussion 🗣 – Enhance your communication and critical thinking abilities.\n" +
            "⿣ One-on-One HR Interview 💼 – Experience real interview scenarios with expert feedback.",
        image: "aiml.jpg",
        registerLink: "https://register.beyondresume.com"
    },
    3: {
        title: "Code Clash",
        department: "ENTC",
        date: "April 7, 2025",
        venue: "Room 302",
        description: "A coding contest for electronics students.",
        image: "images/code-clash.jpg",
        registerLink: "https://register.codeclash.com"
    },
    4: {
        title: "Robotics and Automation Workshop",
        department: "Mechanical Engineering",
        date: "April 16, 2025",
        venue: "Workshop Hall",
        description: "Hands-on training in robotics and automation.",
        image: "images/robotics-workshop.jpg",
        registerLink: "https://register.roboticsworkshop.com"
    },
    5: {
        title: "Building Smart Cities Seminar",
        department: "Civil Engineering",
        date: "April 18, 2025",
        venue: "Main Auditorium",
        description: "Discussion on modern smart city development.",
        image: "images/smart-cities.jpg",
        registerLink: "https://register.smartcities.com"
    },
    6: {
        title: "Renewable Energy Systems Workshop",
        department: "Electrical Engineering",
        date: "April 20, 2025",
        venue: "Lab 2",
        description: "Explore the future of renewable energy technologies.",
        image: "images/renewable-energy.jpg",
        registerLink: "https://register.renewableenergy.com"
    }
};

function openModal(eventId) {
    const event = eventsData[eventId];
    const eventDate = new Date(event.date);
    const currentDate = new Date();

    const modal = document.getElementById("eventModal");
    const modalContent = document.querySelector(".modal-content");
    const modalTitle = document.getElementById("modal-title");
    const modalDepartment = document.getElementById("modal-department");
    const modalDate = document.getElementById("modal-date");
    const modalVenue = document.getElementById("modal-venue");
    const modalDescription = document.getElementById("modal-description");
    const modalImage = document.getElementById("modal-image");
    const registerLink = document.getElementById("register-link");

    // Reset all content
    modalTitle.innerText = "";
    modalDepartment.innerText = "";
    modalDate.innerText = "";
    modalVenue.innerText = "";
    modalDescription.innerHTML = "";
    modalImage.src = "";
    modalImage.alt = "";
    registerLink.style.display = "inline-block";

    // Show modal
    modal.style.display = "flex";

    // Check if registrations are closed
    if (currentDate > eventDate) {
        modalContent.style.backgroundColor = "#ffe5e5"; // light red
        modalDescription.innerHTML = "<h2 style='color: darkred;'>Sorry, the registrations are now closed!!</h2>";
        modalImage.style.display = "none";
        registerLink.style.display = "none";
        return;
    }

    // Reset styling for active events
    modalContent.style.backgroundColor = "rgb(147, 202, 247)";
    modalImage.style.display = "block";

    if (event) {
        modalTitle.innerText = event.title;
        modalDepartment.innerText = event.department;
        modalDate.innerText = event.date;
        modalVenue.innerText = event.venue;
        modalDescription.innerHTML = event.description.replace(/\n/g, "<br>");
        modalImage.src = event.image;
        modalImage.alt = event.title;
        registerLink.href = "register.html?eventName=" + encodeURIComponent(event.title);
    }
}

function closeModal() {
    document.getElementById("eventModal").style.display = "none";
}



