document.addEventListener('DOMContentLoaded', function() {
    fetchTeamMembers();
  });
  
  function fetchTeamMembers() {
    fetch('http://localhost:8080/team/all')
      .then(response => {
        if (!response.ok) throw new Error('Network response was not ok');
        return response.json();
      })
      .then(data => {
        const tableBody = document.getElementById('teamsTableBody');
        tableBody.innerHTML = '';
        
        data.forEach(member => {
          tableBody.innerHTML += `
            <tr>
              <td>${member.name || '-'}</td>
              <td>${member.branch || '-'}</td>
              <td>${member.year || '-'}</td>
              <td>${member.campaigningSchedule || '-'}</td>
              <td>${member.time || '-'}</td>
              <td>${member.faculty || '-'}</td>
            </tr>
          `;
        });
      })
      .catch(error => {
        console.error('Fetch error:', error);
        document.getElementById('teamsTableBody').innerHTML = `
          <tr><td colspan="6">Error loading data</td></tr>
        `;
      });
  }